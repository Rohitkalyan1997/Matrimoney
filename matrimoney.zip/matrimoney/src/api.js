import axios from "axios";

// Set the base URL for your backend
const API_BASE_URL = "http://127.0.0.1:8000"; // change if your FastAPI runs elsewhere

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Signup
export const signupUser = async (data) => {
  return await api.post("/auth/signup", data);
};

// Login
export const loginUser = async (data) => {
  return await api.post("/auth/login", data);
};

export default api;
