import { useState } from "react";
import { Link } from "react-router-dom";
import "./Login.css";

const Login = () => {
  const [identifier, setIdentifier] = useState(""); // email or phone
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    const isEmail = /\S+@\S+\.\S+/.test(identifier);
    const isPhone = /^[0-9]{10}$/.test(identifier);

    if (!isEmail && !isPhone) {
      alert("Please enter a valid email or 10-digit phone number.");
      return;
    }

    console.log("Identifier:", identifier, "Password:", password);
    alert(`Logged in with ${isEmail ? "Email" : "Phone"}: ${identifier}`);
  };

  return (
    <div className="login-container">
      <form className="login-form" onSubmit={handleSubmit}>
        <h1 className="logo">Matrimo</h1>
        <p className="tagline">Find your perfect match</p>

        <input
          type="text"
          placeholder="Email or Phone Number"
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="submit">Login</button>

        <p className="signup-text">
          Don’t have an account? <Link to="/signup">Sign Up</Link>
        </p>

        <div className="social-login">
          <p>Or login with</p>
          <button type="button" className="social-btn google">Google</button>
          <button type="button" className="social-btn facebook">Facebook</button>
        </div>
      </form>
    </div>
  );
};

export default Login;
