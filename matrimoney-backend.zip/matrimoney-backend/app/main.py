from fastapi import FastAPI
from app.database import Base, engine
from app.controller import auth_controller

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Matrimony App API")

# Register routers
app.include_router(auth_controller.router)

@app.get("/")
def root():
    return {"message": "Matrimony API is running!"}
