from sqlalchemy import Column, Integer, String
from app.database import Base

from pydantic import BaseModel, EmailStr
from typing import Optional

'''class SignupRequest(BaseModel):
    name: str
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    password: str '''

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)       # ✅ add length
    email = Column(String(100), unique=True, index=True, nullable=True)
    phone = Column(String(20), unique=True, index=True, nullable=True)
    password = Column(String(600), nullable=False)  # enough for hashed passwords
