from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Replace these with your actual credentials
MYSQL_USER = "root"
MYSQL_PASSWORD = "localpost"
MYSQL_HOST = "localhost"
MYSQL_PORT = "3306"
MYSQL_DB = "matrimony_db"

# Connection string format for PyMySQL
DATABASE_URL = f"mysql+pymysql://root:localpost@localhost:3306/matrimony_db"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
