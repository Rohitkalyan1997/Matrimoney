from sqlalchemy.orm import Session
from app.models.user_model import User

class UserRepository:
    def __init__(self, db):
        self.db = db

    def get_by_email(self, email):
        return self.db.query(User).filter(User.email == email).first()

    def get_by_phone(self, phone):
        return self.db.query(User).filter(User.phone == phone).first()

    def create_user(self, name, email, phone, password):
        user = User(name=name, email=email, phone=phone, password=password)
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user

    def get_user_by_email_or_phone(self, db: Session, identifier: str):
        return db.query(User).filter((User.email == identifier) | (User.phone == identifier)).first()
