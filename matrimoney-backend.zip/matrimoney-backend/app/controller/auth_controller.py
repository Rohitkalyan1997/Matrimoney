from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.services.auth_service import AuthService
from pydantic import BaseModel, EmailStr
from typing import Optional
import traceback

router = APIRouter(prefix="/auth", tags=["Authentication"])
auth_service = AuthService()

class SignupRequest(BaseModel):
    name: str
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    password: str


router = APIRouter(prefix="/auth")
service = AuthService()


@router.post("/signup")
def signup(request: SignupRequest, db: Session = Depends(get_db)):
    try:
        user = service.signup(db, request.name, request.email, request.phone, request.password)
        return {"message": "User created successfully", "user_id": user.id}
    except Exception as e:
        print("ERROR:", e)
        traceback.print_exc()
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/login")
def login(identifier: str, password: str, db: Session = Depends(get_db)):
    user = auth_service.login(db, identifier, password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return {"message": "Login successful", "user": {"id": user.id, "name": user.name}}
