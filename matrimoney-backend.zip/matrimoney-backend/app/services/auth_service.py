import bcrypt
from passlib.context import CryptContext

from app.repository.user_repository import UserRepository

'''pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")'''

class AuthService:
    '''def __init__(self):
        self.user_repo = UserRepository()'''

    def hash_password(self, password: str):
        return pwd_context.hash(password)

    def verify_password(self, plain_password, hashed_password):
        safe_password = plain_password[:72].encode('utf-8')
        return bcrypt.checkpw(safe_password, hashed_password.encode('utf-8'))

    def signup(self, db, name, email=None, phone=None, password=None):
        repo = UserRepository(db)

        if email and repo.get_by_email(email):
            raise Exception("Email already exists")
        if phone and repo.get_by_phone(phone):
            raise Exception("Phone already exists")

        # ✅ Truncate password to 72 characters
        safe_password = password[:72].encode('utf-8')  

        # Hash password
        hashed_password = bcrypt.hashpw(safe_password, bcrypt.gensalt()).decode('utf-8')
        user = repo.create_user(name, email, phone, hashed_password)
        print("DEBUG: User created", user.id)
        return user

    def login(self, db, identifier, password):
        repo = UserRepository(db)
        user = repo.get_user_by_email_or_phone(db, identifier)

        if user and self.verify_password(password, user.password):
            return user
        return None
